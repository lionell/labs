#ifndef IOLIB_H
#define IOLIB_H

#include "testlib.h"

// Print welcome message
void Welcome(Modes);

// Check if char* is number
bool isNumber(char*);

// Print result of test from test case
void PrintOut(Test**, int, Verdicts);

// Let's summarize our achievements
void Summarize(int);

// Special for Semi-Automatic mode
void PrintOut(int*, int, double*);

// Special for Automatic mode
void PrintOut(double*);

int ReadArraySize();

int *ReadArray(int);

#endif