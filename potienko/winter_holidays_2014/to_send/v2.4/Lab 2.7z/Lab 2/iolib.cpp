#include "iolib.h"
#include <iostream>
/* cin, cout */
#include <string.h>
/* strlen */

using namespace std;

// Print welcome message
void Welcome(Modes mode) {
    cout << "Welcome to Winter Holidays Lab 2!" << endl << endl;
    if (mode == Modes::manual) {
        cout << "This is manual mode" << endl;
    }
    else if (mode == Modes::semi_automatic) {
        cout << "This is semi-automatic mode" << endl;
    }
    else if (mode == Modes::automatic) {
        cout << "This is automatic mode" << endl;
    }
    else {
        cout << "This is help mode" << endl;
        cout << "To run this application in some mode you should use '-m' or '--mode' command line argument with value: " << endl;
        cout << " 1) Manual mode(User enter element count and all of elements)" << endl;
        cout << " 2) Semi-automatic mode(User enter element count and all of elements generates randomly)" << endl;
        cout << " 3) Automatic mode(User doesn't enter anything)" << endl;
    }
}

// Check if char* is number
bool isNumber(char *s) {
    bool result = true;
    for (int i = 0; i < strlen(s); ++i) {
        if (!isdigit(s[i])) {
            result = false;
            // When we found non-digit we can stop
            break;
        }
    }
    return result;
}

// Print result of test from test case
void PrintOut(Test **tests, int number_of_test, Verdicts verdict) {
cout << "Test #" << number_of_test << '.' << endl;
// Print input array
cout << "Input: ";
for (int i = 0; i < tests[number_of_test]->input_array_size - 1; ++i) {
cout << tests[number_of_test]->input_array[i] << ", ";
}
// After last element we don't need to print comma
cout << tests[number_of_test]->input_array[tests[number_of_test]->input_array_size - 1] << endl;
// Print verdict
cout << "Verdict: ";
if (verdict == Verdicts::passed) cout << "passed";
else if (verdict == Verdicts::failed) cout << "failed";
else cout << "error";
cout << '.' << endl << endl;
}

// Let's summarize our achievements
void Summarize(int passed_test_count) {
    cout << "Finaly " << passed_test_count << " of " << test_count << " passed." << endl;
    cout << "Persentage of success: " << (double(passed_test_count) * 100.0 / double(test_count)) << "%" << endl;
}

// Special for Semi-Automatic mode
void PrintOut(int *input_array, int input_array_size, double *output_array) {
    cout << "Function recieved: ";
    for (int i = 0; i < input_array_size - 1; ++i) {
        cout << input_array[i] << ", ";
    }
    cout << input_array[input_array_size - 1] << endl;

    cout << "Function returned: ";
    for (int i = 0; i < 10; ++i) {
        cout << output_array[i] << ", ";
    }
    cout << output_array[10] << endl;
}

// Special for Automatic mode
void PrintOut(double *output_array) {
    cout << "Function returned: ";
    for (int i = 0; i < 10; ++i) {
        cout << output_array[i] << ", ";
    }
    cout << output_array[10] << endl;
}

int ReadArraySize() {
    int result = 0;
    cout << "Enter array size: ";
    cin >> result;
    return result;
}

int *ReadArray(int size) {
    cout << "Enter elements of array: ";
    int *result = new int[size];
    for (int i = 0; i < size; ++i) {
        cin >> result[i];
    }
    return result;
}