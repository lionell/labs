#include "mainlib.h"

// Main function in this project
double *Evaluate(int *input_array, int input_array_size) {
    // Let's create a new dynamic array to return
    double *result = new double[11]();
    // Find count of each element in cells of result
    for (int i = 0; i < input_array_size; ++i) {
        result[input_array[i]]++;
    }
    // Divide each result cell by input_array_size. Don't forget to convert to double!
    for (int i = 0; i < 11; ++i) {
        result[i] = result[i] * 100.0 / static_cast<double>(input_array_size);
    }
    return result;
}