#include <stdlib.h>
#include <time.h>
#include "utillib.h"

// Generate all elements of array randomly
int *GenerateRandomArray(int input_array_size) {
    // Create new array in dynamic memory to return
    int *result = new int[input_array_size];
    // Plant a random seed
    srand(static_cast<unsigned int>(time(0)));
    for (int i = 0; i < input_array_size; ++i) {
        // Here rand() returns random value from range [0..RAND_MAX] and we should take it by modulo 11
        result[i] = rand() % 11;
    }
    return result;
}