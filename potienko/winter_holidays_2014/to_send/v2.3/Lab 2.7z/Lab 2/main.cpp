/* Автор: Руслан Сакевич
* Модифікувати лабораторну роботу №1 таким чином, щоб програма могла працювати
* в 3‐х режимах (режим задається параметрами командного рядка):
*
* 1. Кількість елементів та самі елементи вводить користувач;
* 2. Користувач вводить кількість елементів, масив заповнюється випадковими числами;
* 3. Програма працює в режимі лабораторної роботи №1.
*/
#include <stdlib.h>
#include <string.h>
/* strcmp */
#include "testlib.h"
#include "iolib.h"

// Main function parse application arguments to run in appropriate mode
int main(int argv, char *argc[]) {
    // Let's check how many arguments we have
    if (argv == 3) {
        // Compare second argument to '-m' or '--mode'
        if (strcmp(argc[1], "-m") == 0 || strcmp(argc[1], "--mode") == 0) {
            // Check if third argument is number
            if (isNumber(argc[2])) {
                // Convert char* to int
                int mode = atoi(argc[2]);
                // And check if number fits range
                if (mode == 1) {
                    // Manual mode
                    Welcome(Modes::manual);
                    Manual();
                }
                else if (mode == 2) {
                    // Semi-automatic mode
                    Welcome(Modes::semi_automatic);
                    SemiAutomatic();
                }
                else if (mode == 3) {
                    // Automatic mode
                    Welcome(Modes::automatic);
                    Automatic();
                }
                else Welcome(Modes::help); // Invalid mode number
            }
            else Welcome(Modes::help); // Third argument is not a number
        }
        else Welcome(Modes::help); // No '-m' or '--mode' argument found
    }
    else Welcome(Modes::help); // Invalid argument count
    return 0;
}