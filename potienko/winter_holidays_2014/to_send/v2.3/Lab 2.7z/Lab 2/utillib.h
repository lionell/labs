#ifndef UTILLIB_H
#define UTILLIB_H

int *GenerateRandomArray(int);

#endif