#ifndef MAINLIB_H
#define MAINLIB_H

double *Evaluate(int*, int);

#endif