/* Автор: Руслан Сакевич
* Дано масив цілих чисел від 0 до 10 включно (надалі вхідний масив).
* Програма повинна побудувати масив з 11 елементів та заповнити його дійсними числами наступним чином:
* значення i-го елементу масиву–це відсоток входжень числа i у вхідний масив відносно всієї кількості
* елементів вхідного масиву.
*
* Наприклад:
* Вхідний масив містить 10 елементів: 0, 0, 1, 2, 3, 4, 3, 2, 1, 0.
* Побудований програмою масив буде мати вигляд: 30.0, 20, 20, 20, 10, 0, 0, 0, 0, 0, 0.
*
* Програма повинна запускатись для тестових даних, підібраних виконавцем.
*
* Програма повинна повідомляти зміст тесту та його результат (успішний чи ні).
*/
#include <iostream>
/* cin, cout */
#include <cmath>
/* abs(double) */

#include "testlib.h"
#include "iolib.h"

using namespace std;

/* Define global constant */
const double EPS = 1e-2;

// <editor-fold desc="Main function">

// Main function in this project
double *Evaluate(int *input_array, int input_array_size) {
    // Let's create a new dynamic array to return
    double *result = new double[11]();
    // Find count of each element in cells of result
    for (int i = 0; i < input_array_size; ++i) {
        result[input_array[i]]++;
    }
    // Divide each result cell by input_array_size. Don't forget to convert to double!
    for (int i = 0; i < 11; ++i) {
        result[i] = result[i] * 100.0 / static_cast<double>(input_array_size);
    }
    return result;
}

// </editor-fold>

// <editor-fold desc="Check function">

// Check if two arrays are equal
bool Equal(double *first, double *second) {
    // We need variable to return
    bool result = true;
    for (int i = 0; i < 11; ++i) {
        if (abs(first[i] - second[i]) > EPS) {
            result = false;
            // When we found difference we can stop comparison
            break;
        }
    }
    return result;
}

// Check out function on a full test case
void CheckAllTests(Test **tests) {
    // Let's define global variables for function
    double *returned_array = nullptr;
    Verdicts verdict = Verdicts::none;
    int passed_test_count = 0;
    // Check all tests we have
    for (int i = 0; i < test_count; ++i) {
        // Make out function work
        returned_array = Evaluate(tests[i]->input_array, tests[i]->input_array_size);
        // And compare results
        verdict = (Equal(tests[i]->output_array, returned_array)) ? Verdicts::passed : Verdicts::failed;
        passed_test_count += (verdict == Verdicts::passed) ? 1 : 0;
        // Print out information about test
        PrintOut(tests, i, verdict);
        delete[] returned_array;
    }
    Summarize(passed_test_count);
}

// </editor-fold>

int main() {
    // Print out a welcome text
    Welcome();
    // Set up tests
    Test **tests = SetupTests();
    // Do a check
    CheckAllTests(tests);
    // Release the memory
    FreeTests(tests);
    return 0;
}