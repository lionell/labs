#ifndef IOLIB_H
#define IOLIB_H

#include "testlib.h"

// Print welcome message
void Welcome();

// Print result of test
void PrintOut(Test**, int, Verdicts);

// Let's summarize our achievements
void Summarize(int);

#endif