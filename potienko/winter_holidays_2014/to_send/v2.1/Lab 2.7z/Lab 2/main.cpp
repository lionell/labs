/* Автор: Руслан Сакевич
* Модифікувати лабораторну роботу №1 таким чином, щоб програма могла працювати
* в 3‐х режимах (режим задається параметрами командного рядка):
*
* 1. Кількість елементів та самі елементи вводить користувач;
* 2. Користувач вводить кількість елементів, масив заповнюється випадковими числами;
* 3. Програма працює в режимі лабораторної роботи №1.
*/
#include <iostream>
/* cin, cout */
#include <cmath>
/* abs(double) */
#include <string.h>
/* strcmp */
#include "testlib.h"
#include "iolib.h"

using namespace std;

/* Define global constant */
const double EPS = 1e-2;

// <editor-fold desc="Main function">

// Main function in this project
double *Evaluate(int *input_array, int input_array_size) {
    // Let's create a new dynamic array to return
    double *result = new double[11]();
    // Find count of each element in cells of result
    for (int i = 0; i < input_array_size; ++i) {
        result[input_array[i]]++;
    }
    // Divide each result cell by input_array_size. Don't forget to convert to double!
    for (int i = 0; i < 11; ++i) {
        result[i] = result[i] * 100.0 / static_cast<double>(input_array_size);
    }
    return result;
}

// </editor-fold>

// <editor-fold desc="Check function">

// Check if two arrays are equal
bool Equal(double *first, double *second) {
    // We need variable to return
    bool result = true;
    for (int i = 0; i < 11; ++i) {
        if (abs(first[i] - second[i]) > EPS) {
            result = false;
            // When we found difference we can stop comparison
            break;
        }
    }
    return result;
}

// Check out function on a full test case
void CheckAllTests(Test **tests) {
    // Let's define global variables for function
    double *returned_array = nullptr;
    Verdicts verdict = Verdicts::none;
    int passed_test_count = 0;
    // Check all tests we have
    for (int i = 0; i < test_count; ++i) {
        // Make out function work
        returned_array = Evaluate(tests[i]->input_array, tests[i]->input_array_size);
        // And compare results
        verdict = (Equal(tests[i]->output_array, returned_array)) ? Verdicts::passed : Verdicts::failed;
        passed_test_count += (verdict == Verdicts::passed) ? 1 : 0;
        // Print out information about test
        PrintOut(tests, i, verdict);
        delete[] returned_array;
    }
    Summarize(passed_test_count);
}

// </editor-fold>

// <editor-fold desc="Application modes">

// Manual mode from description above
void Manual() {
    int input_array_size = 0;
    cout << "Enter array size: ";
    cin >> input_array_size;
    cout << "Enter elements of array: ";
    int *input_array = new int[input_array_size];
    for (int i = 0; i < input_array_size; ++i) {
        cin >> input_array[i];
    }
    double *output_array = Evaluate(input_array, input_array_size);
    PrintOut(output_array);
    delete[] input_array;
    delete[] output_array;
}

// Generate all elements of array randomly
int *GenerateRandomArray(int input_array_size) {
    // Create new array in dynamic memory to return
    int *result = new int[input_array_size];
    // Plant a random seed
    srand(static_cast<unsigned int>(time(0)));
    for (int i = 0; i < input_array_size; ++i) {
        // Here rand() returns random value from range [0..RAND_MAX] and we should take it by modulo 11
        result[i] = rand() % 11;
    }
    return result;
}

// Semi-Automatic mode from description above
void SemiAutomatic() {
    // Let's read array_size
    int input_array_size = 0;
    cout << "Enter array size: ";
    cin >> input_array_size;
    // Let's note the time of array generation
    clock_t start_time = clock();
    int *input_array = GenerateRandomArray(input_array_size);
    clock_t finish_time = clock();
    // Of course using clock() is bad idea, because of its time error, but there is no another simple way
    cout << "Array randomly generated in " << static_cast<unsigned int>(finish_time - start_time) << "ms." << endl;
    // Evaluate result
    double *output_array = Evaluate(input_array, input_array_size);
    // And print it out in appropriate way
    PrintOut(input_array, input_array_size, output_array);
    // Clean up memory
    delete[] input_array;
    delete[] output_array;
}

// Automatic mode from description above
void Automatic() {
    // This part is from Lab 1
    Test **tests = SetupTests();
    CheckAllTests(tests);
    FreeTests(tests);
}

// </editor-fold>

// Main function parse application arguments to run in appropriate mode
int main(int argv, char *argc[]) {
    // Let's check how many arguments we have
    if (argv == 3) {
        // Compare second argument to '-m' or '--mode'
        if (strcmp(argc[1], "-m") == 0 || strcmp(argc[1], "--mode") == 0) {
            // Check if third argument is number
            if (isNumber(argc[2])) {
                // Convert char* to int
                int mode = atoi(argc[2]);
                // And check if number fits range
                if (mode == 1) {
                    // Manual mode
                    Welcome(Modes::manual);
                    Manual();
                }
                else if (mode == 2) {
                    // Semi-automatic mode
                    Welcome(Modes::semi_automatic);
                    SemiAutomatic();
                }
                else if (mode == 3) {
                    // Automatic mode
                    Welcome(Modes::automatic);
                    Automatic();
                }
                else Welcome(Modes::help); // Invalid mode number
            }
            else Welcome(Modes::help); // Third argument is not a number
        }
        else Welcome(Modes::help); // No '-m' or '--mode' argument found
    }
    else Welcome(Modes::help); // Invalid argument count
    return 0;
}