#ifndef TESTLIB_H
#define TESTLIB_H

// Define special Test structure to manipulate tests easier
struct Test {
    int *input_array;
    int input_array_size;
    double *output_array;
};

// Let's enumerate all possible verdicts
enum class Verdicts {
    none, // default value for initializing(not used)
    passed,
    failed
};

// Let's enumerate available modes in application
enum class Modes {
    manual,
    semi_automatic,
    automatic,
    help
};

const int test_count = 11;

// Setup basic information for tests(e.g. input_array, input_array_size, output_array)
Test **SetupTests();

// Let's free our memory
void FreeTests(Test**);

#endif