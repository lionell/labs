/* Автор: Руслан Сакевич
* Дано масив цілих чисел від 0 до 10 включно (надалі вхідний масив).
* Програма повинна побудувати масив з 11 елементів та заповнити його дійсними числами наступним чином:
* значення i-го елементу масиву–це відсоток входжень числа i у вхідний масив відносно всієї кількості
* елементів вхідного масиву.
*
* Наприклад:
* Вхідний масив містить 10 елементів: 0, 0, 1, 2, 3, 4, 3, 2, 1, 0.
* Побудований програмою масив буде мати вигляд: 30.0, 20, 20, 20, 10, 0, 0, 0, 0, 0, 0.
*
* Програма повинна запускатись для тестових даних, підібраних виконавцем.
*
* Програма повинна повідомляти зміст тесту та його результат (успішний чи ні).
*/
#include <iostream>
/* cin, cout */
#include <cmath>
/* abs(double) */

using namespace std;

/* Define global constant */
const double EPS = 1e-2;

// <editor-fold desc="Tests Description">

// Define special Test structure to manipulate tests easier
struct Test {
    int *input_array;
    int input_array_size;
    double *output_array;
};

// Let's enumerate all possible verdicts
enum class Verdicts {
    none, // default value for initializing(not used)
    passed,
    failed
};

const int test_count = 11;

// Setup basic information for tests(e.g. input_array, input_array_size, output_array)
Test **SetupTests() {
    // Define array to return from our function
    Test **tests = new Test*[test_count];
    // First one
    tests[0] = new Test();
    tests[0]->input_array = new int[1] {0};
    tests[0]->input_array_size = 1;
    tests[0]->output_array = new double[11] {100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    // Second one
    tests[1] = new Test();
    tests[1]->input_array = new int[7] {1, 2, 3, 4, 5, 6, 7};
    tests[1]->input_array_size = 7;
    tests[1]->output_array = new double[11] {0.0, 14.29, 14.29, 14.29, 14.29, 14.29, 14.29, 14.29, 0.0, 0.0, 0.0};
    // Third one
    tests[2] = new Test();
    tests[2]->input_array = new int[10] {0, 0, 0, 1, 3, 2, 2, 0, 1, 7};
    tests[2]->input_array_size = 10;
    tests[2]->output_array = new double[11] {40.0, 20.0, 20.0, 10.0, 0.0, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0};
    // Fourth one
    tests[3] = new Test();
    tests[3]->input_array = new int[9] {7, 7, 3, 2, 2, 9, 8, 8, 9};
    tests[3]->input_array_size = 9;
    tests[3]->output_array = new double[11] {0.0, 0.0, 22.22, 11.11, 0.0, 0.0, 0.0, 22.22, 22.22, 22.22, 0.0};
    // Fifth one
    tests[4] = new Test();
    tests[4]->input_array = new int[11] {7, 7, 3, 2, 2, 9, 8, 8, 9, 0, 0};
    tests[4]->input_array_size = 11;
    tests[4]->output_array = new double[11] {18.18, 0.0, 18.18, 9.09, 0.0, 0.0, 0.0, 18.18, 18.18, 18.18, 0.0};
    // Sixth one
    tests[5] = new Test();
    tests[5]->input_array = new int[12] {7, 7, 3, 2, 2, 9, 8, 8, 9, 8, 9, 1};
    tests[5]->input_array_size = 12;
    tests[5]->output_array = new double[11] {0.0, 8.33, 16.67, 8.33, 0.0, 0.0, 0.0, 16.67, 25.0, 25.0, 0.0};
    // Seventh one
    tests[6] = new Test();
    tests[6]->input_array = new int[5] {2, 9, 8, 8, 9};
    tests[6]->input_array_size = 5;
    tests[6]->output_array = new double[11] {0.0, 0.0, 20.0, 0.0, 0.0, 0.0, 0.0, 0.0, 40.0, 40.0, 0.0};
    // Eighth one
    tests[7] = new Test();
    tests[7]->input_array = new int[2] {7, 7};
    tests[7]->input_array_size = 2;
    tests[7]->output_array = new double[11] {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 100.0, 0.0, 0.0, 0.0};
    // Ninth one
    tests[8] = new Test();
    tests[8]->input_array = new int[3] {1, 2, 3};
    tests[8]->input_array_size = 3;
    tests[8]->output_array = new double[11] {0.0, 33.33, 33.33, 33.33, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    // Tenth one
    tests[9] = new Test();
    tests[9]->input_array = new int[8] {8, 8, 2, 2, 9, 8, 8, 9};
    tests[9]->input_array_size = 8;
    tests[9]->output_array = new double[11] {0.0, 0.0, 25.0, 0.0, 0.0, 0.0, 0.0, 0.0, 50.0, 25.0, 0.0};
    // Eleventh one
    tests[10] = new Test();
    tests[10]->input_array = new int[10] {0, 0, 1, 2, 3, 4, 3, 2, 1, 0};
    tests[10]->input_array_size = 10;
    tests[10]->output_array = new double[11] {30.0, 20.0, 20.0, 20.0, 10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

    return tests;
}

// Let's free our memory
void FreeTests(Test **tests) {
    for (int i = 0; i < test_count; ++i) {
        delete[] tests[i]->input_array;
        delete[] tests[i]->output_array;
    }
    delete[] tests;
}

// </editor-fold>

// <editor-fold desc="Main function">

// Main function in this project
double *Evaluate(int *input_array, int input_array_size) {
    // Let's create a new dynamic array to return
    double *result = new double[11]();
    // Find count of each element in cells of result
    for (int i = 0; i < input_array_size; ++i) {
        result[input_array[i]]++;
    }
    // Divide each result cell by input_array_size. Don't forget to convert to double!
    for (int i = 0; i < 11; ++i) {
        result[i] = result[i] * 100.0 / static_cast<double>(input_array_size);
    }
    return result;
}

// </editor-fold>

// <editor-fold desc="I/O functions">

// Print welcome message
void Welcome() {
    cout << "Welcome to Winter Holidays Lab 1!" << endl << endl;
}

// Print result of test
void PrintOut(Test **tests, int number_of_test, Verdicts verdict) {
    cout << "Test #" << number_of_test << '.' << endl;
    // Print input array
    cout << "Input: ";
    for (int i = 0; i < tests[number_of_test]->input_array_size; ++i) {
        cout << tests[number_of_test]->input_array[i] << ' ';
    }
    cout << endl;
    // Print verdict
    cout << "Verdict: ";
    if (verdict == Verdicts::passed) cout << "passed";
    else if (verdict == Verdicts::failed) cout << "failed";
    else cout << "error";
    cout << '.' << endl << endl;
}

// Let's summarize our achievements
void Summarize(int passed_test_count) {
    cout << "Finaly " << passed_test_count << " of " << test_count << " passed." << endl;
    cout << "Persentage of success: " << (double(passed_test_count) * 100.0 / double(test_count)) << "%" << endl;
}

// </editor-fold>

// <editor-fold desc="Check function">

// Check if two arrays are equal
bool Equal(double *first, double *second) {
    // We need variable to return
    bool result = true;
    for (int i = 0; i < 11; ++i) {
        if (abs(first[i] - second[i]) > EPS) {
            result = false;
            // When we found difference we can stop comparison
            break;
        }
    }
    return result;
}

// Check out function on a full test case
void CheckAllTests(Test **tests) {
    // Let's define global variables for function
    double *returned_array = nullptr;
    Verdicts verdict = Verdicts::none;
    int passed_test_count = 0;
    // Check all tests we have
    for (int i = 0; i < test_count; ++i) {
        // Make out function work
        returned_array = Evaluate(tests[i]->input_array, tests[i]->input_array_size);
        // And compare results
        verdict = (Equal(tests[i]->output_array, returned_array)) ? Verdicts::passed : Verdicts::failed;
        passed_test_count += (verdict == Verdicts::passed) ? 1 : 0;
        // Print out information about test
        PrintOut(tests, i, verdict);
        delete[] returned_array;
    }
    Summarize(passed_test_count);
}

// </editor-fold>

int main() {
    // Print out a welcome text
    Welcome();
    // Set up tests
    Test **tests = SetupTests();
    // Do a check
    CheckAllTests(tests);
    // Release the memory
    FreeTests(tests);
    return 0;
}