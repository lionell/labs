#ifndef MAINLIB_H
#define MAINLIB_H

// Main function in this project
double *Evaluate(int*, int);

#endif