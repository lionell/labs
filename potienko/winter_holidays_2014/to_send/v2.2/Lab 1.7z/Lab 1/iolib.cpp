#include "iolib.h"
#include <iostream>
/* cin, cout */

using namespace std;

// Print welcome message
void Welcome() {
    cout << "Welcome to Winter Holidays Lab 1!" << endl << endl;
}

// Print result of test
void PrintOut(Test **tests, int number_of_test, Verdicts verdict) {
    cout << "Test #" << number_of_test << '.' << endl;
    // Print input array
    cout << "Input: ";
    for (int i = 0; i < tests[number_of_test]->input_array_size; ++i) {
        cout << tests[number_of_test]->input_array[i] << ' ';
    }
    cout << endl;
    // Print verdict
    cout << "Verdict: ";
    if (verdict == Verdicts::passed) cout << "passed";
    else if (verdict == Verdicts::failed) cout << "failed";
    else cout << "error";
    cout << '.' << endl << endl;
}

// Let's summarize our achievements
void Summarize(int passed_test_count) {
    cout << "Finaly " << passed_test_count << " of " << test_count << " passed." << endl;
    cout << "Persentage of success: " << (double(passed_test_count) * 100.0 / double(test_count)) << "%" << endl;
}