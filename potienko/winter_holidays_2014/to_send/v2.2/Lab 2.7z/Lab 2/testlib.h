#ifndef TESTLIB_H
#define TESTLIB_H

// Define special Test structure to manipulate tests easier
struct Test {
    int *input_array;
    int input_array_size;
    double *output_array;
};

// Let's enumerate all possible verdicts
enum class Verdicts {
    none, // default value for initializing(not used)
    passed,
    failed
};

// Let's enumerate available modes in application
enum class Modes {
    manual,
    semi_automatic,
    automatic,
    help
};

/* Define global constant */
const double EPS = 1e-2;

const int test_count = 11;

// Setup basic information for tests(e.g. input_array, input_array_size, output_array)
Test **SetupTests();

// Let's free our memory
void FreeTests(Test**);

// Check if two arrays are equal
bool Equal(double*, double*);

// Check out function on a full test case
void CheckAllTests(Test**);

// Manual mode from description above
void Manual();

// Generate all elements of array randomly
int *GenerateRandomArray(int);

// Semi-Automatic mode from description above
void SemiAutomatic();

// Automatic mode from description above
void Automatic();

#endif