#ifndef AUTHOR_H
#define AUTHOR_H

void ReadName(int argv, char** argc);
void WriteCopyright();

#endif