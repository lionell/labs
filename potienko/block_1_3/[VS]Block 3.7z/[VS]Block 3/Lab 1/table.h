#ifndef _TABLE_H_
#define _TABLE_H_

void DrawTable(double*);

#endif