#ifndef _IOLIB_H_
#define _IOLIB_H_

bool TryToReadDouble(double&);
bool TryToReadNatural(int&);

#endif