#ifndef _TABLE_H_
#define _TABLE_H_

const int colsCount = 6;
const int spacesBetween = 6;

void DrawTable(double**, int);

#endif