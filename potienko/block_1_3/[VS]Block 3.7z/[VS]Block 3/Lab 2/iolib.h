#ifndef _IOLIB_H_
#define _IOLIB_H_

const int rowsOnPage = 10;

bool TryToReadDouble(double&);
bool TryToReadNatural(int&);

#endif