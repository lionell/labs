#ifndef _CMDLIB_H_
#define _CMDLIB_H_

void ReadName(int, char**);
void WriteCopyright();

#endif