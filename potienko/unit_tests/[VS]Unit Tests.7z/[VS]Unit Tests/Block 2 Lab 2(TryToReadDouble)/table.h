#ifndef _TABLE_H_
#define _TABLE_H_

const int colsCount = 7;

void DrawTable(std::string**, int);

#endif