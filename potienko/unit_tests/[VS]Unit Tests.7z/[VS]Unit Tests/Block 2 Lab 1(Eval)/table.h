#ifndef _TABLE_H_
#define _TABLE_H_

const int colsCount = 5;

void DrawTable(std::string**, int);

#endif