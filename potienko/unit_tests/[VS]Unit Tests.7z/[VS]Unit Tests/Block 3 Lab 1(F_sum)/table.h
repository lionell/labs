#ifndef _TABLE_H_
#define _TABLE_H_

const int colsCount = 8;

void DrawTable(std::string**, int);

#endif